import requests
from bs4 import BeautifulSoup
soup = BeautifulSoup('<p>data</p>', 'html.parser')#要解析的代码和解析器



