"""
eat [POST] https://primera.e-sim.org/eat.html

"""