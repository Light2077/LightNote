import log

from flower import iris, violet
from fruit import apple, orange




if __name__ == "__main__":
    iris.show()
    violet.show()
    apple.show()
    orange.show()
    1/0